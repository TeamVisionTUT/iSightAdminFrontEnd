
<?php
 
require 'connection.php';
$conn    = Connect();
$cust_id    = $conn->real_escape_string($_POST['cust_id']);
$cust_fname    = $conn->real_escape_string($_POST['cust_fname']);
$cust_lname  = $conn->real_escape_string($_POST['cust_lname']);
$email    = $conn->real_escape_string($_POST['email']);
$contacts = $conn->real_escape_string($_POST['contacts']);
$cust_address = $conn->real_escape_string($_POST['cust_address']);
$password = $conn->real_escape_string($_POST['password']);
$confirm_pass = $conn->real_escape_string($_POST['confirm_pass']);
$query   = "INSERT into customer (cust_id,cust_fname,cust_lname,email,contacts,cust_address,password,confirm_pass) VALUES('" . $cust_id . "','" . $cust_fname . "','" . $cust_lname . "','" . $email . "','" . $contacts . "','" . $cust_address ."','". $password . "','" . $confirm_pass . "' )";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
echo "Thank You For Contacting Us your account is created<br>";
 
$conn->close();
 
?>


