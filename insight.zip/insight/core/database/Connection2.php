<?php 
$dbServerName = "192.168.43.38";
$dbUsername = "web";
$dbPassword = "web";
$dbName = "isightdb";

$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);

if($conn->connect_error)
{
	die("connected faild:" - $conn->connect_error);
	
}
echo "connected successfully";

?>