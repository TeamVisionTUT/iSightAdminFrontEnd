<?php
return[
	'name' => 'isightdb',
	'username' => 'web',
	'password' => 'web',
	'connection' => 'mysql:host=192.168.43.38',
	'options' => [
		PDO::ATTR_PERSISTENT    => true,
    	PDO::ATTR_ERRMODE       => PDO::ERRMODE_EXCEPTION,
    	PDO::ATTR_EMULATE_PREPARES => false
	]
	
];