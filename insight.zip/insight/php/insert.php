<?php
	
	require '../core/database/Connection.php';
	//require '../core/database/QueryBuilder.php';

	$surname =$_POST['surname'];
	$first_name  = $_POST['first_name'];
	$email  = $_POST['email'];
	$phone  = $_POST['phone'];
	
	$sql = "INSERT INTO user (surname,first_name,email,phone,loction_id,id_number,'password') VALUE('$surname','$first_name','$email','$phone','','','')";
	
	//header["refresh:2 url=user.php"];
?>