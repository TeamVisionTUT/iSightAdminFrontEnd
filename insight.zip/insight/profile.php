<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Profile | ISight</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/ISight.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">
	
	<script>
	
	$(document).ready(function() 
	{
		var readURL = function(input) 
		{
			if (input.files && input.files[0]) 
			{
				var reader = new FileReader();

				reader.onload = function (e) 
				{
					$('.avatar').attr('src', e.target.result);
				}
    
				reader.readAsDataURL(input.files[0]);
			}
		}
    

		$(".file-upload").on('change', function()
		{
			readURL(this);
		});
	});
	</script>


</head>

<body>
	
	
    <div class="brand">ISight</div>

    <!-- Navigation -->
    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- navbar-brand is hidden on larger screens, but visible when the menu is collapsed -->
				<a class="navbar-brand" href="index.html">ISight</a>
				
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
               <ul class="nav navbar-nav">
                    <li>
                        <a href="user.php">User Info</a>
                    </li>
					<li>
                        <a href="location.php">User Location</a>
                    </li>
                    <li>
                        <a href="items.php">User Items</a>
                    </li>
                    <li>
                        <a href="fav.php">User Fav Items</a>
                    </li>
					<li>
                        <a href="signOut.html">Sign Out</a>
                    </li>
					<li>
                        <?php 
						
						include 'controllers/Controller.php';
						
						$run = new Controller();
						$id = $_SESSION['user_id'];
						$user = $run->getUserInfo($id);
						
						$name = $user[0]['surname'];
						$first_name = $user[0]['first_name'];
						
						
						echo $name;
					
						?>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	<hr>
	<div class="container">
        <div class="row">
            <div class="box">
                <div class="col-lg-12 text-left">
					<div class="intro-text text-center" ><h3>Personal Details</h3></div>
					<!--div class="col-sm-2"><a href="/users" class="pull-right"><img title="profile image" class="img-circle img-responsive" src="http://www.gravatar.com/avatar/28fd20ccec6865e2d5f0e1f4446eb7bf?s=100"></a></div-->
					<div class="intro-text text-center">
						
						<img src="20180914_213136.jpg" class="avatar img-circle img-thumbnail" alt="avatar" width="30%">
						<h6>Upload a different photo...</h6>
						<input type="file" class="text-center center-block file-upload" onchange="readURL(this);">
						
						<!--img src = input type="file" class="text-center center-block file-upload">
						  <input type='file' onchange="readURL(this);" />
							<img id="blah" src = "#" alt="your image" /-->
					</div>
					
                </div>
            </div>
        </div>
    </div>


	  

    <div class="container">

        <div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <form name="form" class="col-lg-12 text-center" action=""  method="get">
							<table>
								<tr>
									<th><h4><b>Surname:</h4></b>
									</th>
									<th>
										<label><input type="surname" name="surname" class="form-control" value="<?php $name = $user[0]['surname']; echo $name;?>"></label>
									</th>
								</tr>
								<tr>
									<th><h4><b>First Name:</h4></b>
									</th>
									<th>
										<label><input widt="700px" type="first_name" name="first_name" class="form-control" value="<?php $first_name = $user[0]['first_name']; echo $first_name;?>"></label>
									</th>
								</tr>
								<tr>
									<th><h4><b>ID Number:</h4></b>
									</th>
									<th>
										<?php $id_number = $user[0]['id_number']; echo $id_number;?>
									</th>
								</tr>
								<tr>
									<th><h4><b>Email Address:</h4></b>
									</th>
									<th>
										<label><input type="email" name="email" class="form-control" value="<?php $email = $user[0]['email']; echo $email;?>"></label>
									</th>
								</tr>
								<tr>
									<th><h4><b>Contact Numbers:</h4></b>
									</th>
									<th>
										<label><input type="phone" name="phone" class="form-control" value="<?php $phone = $user[0]['phone']; echo $phone;?>"></label>
									</th>
								</tr>
								<tr>
									<th><h4><b>Location ID:</h4></b>
									</th>
									<th>
										<?php $location_id = $user[0]['location_id']; echo $location_id;?>
									</th>
								</tr>
								
							</table>
                    </form>
				
                </div>
            </div>
        </div>

    </div>


    <div class="container">

        <div class="row">
            <div class="box">
                <div class="col-lg-12 text-center">
					
					<div class="form-group col-lg-12">
                    <input type="hidden" name="save" value="contact">
                    <button type="submit" class="btn btn-default" name = "update">Update My Profile</button>
					<!--?php updateUSER($surname,$first_name,$email,$phone,$user_id);?-->
					
					<!--input type="submit" value="submit id" id='clickme'-->
										<script> 
											$('#clickme').click(function() 
												{       
													$('#result').html('<?php ?>')  
												})  
										</script>
										<p id='result'> im daniel </p>
                    </div>
			
				</div>
			</div>
		</div>	
	</div>
    <!-- /.container -->
	
	<?php
	//include 'controllers/userController.php';

	//$run = new UserController();

		if(isset($_GET['surname']) && isset($_GET['first_name']) && isset($_GET['email']) && isset($_GET['phone'])){
			$username = $_GET['surname'];
			$first_name = $_GET['first_name'];
			$email = $_GET['email'];
			$phone = $_GET['phone'];
			$user_id = $_GET['user_id'];
			
			$run-> updateUSER($surname,$first_name,$email,$phone,$user_id);
		}

	?>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>Copyright &copy ISight<br />
						Design &amp development by TeamVisionTUT<br />
					</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
