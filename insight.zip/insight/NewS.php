<?php 
	// this will trigger when submit button click
	if(isset($_POST['sub'])){
  
		$db = new mysqli("localhost","root","","zencr");
 
		// create query
		$query = "SELECT * FROM customer WHERE email='".$_POST['uname']."' AND password='".$_POST['psw']."'";
 

 
		// execute query
		$sql = $db->query($query);
		// num_rows will count the affected rows base on your sql query. so $n will return a number base on your query
		$n = $sql->num_rows;
 
		// if $n is > 0 it mean their is an existing record that match base on your query above 
		if($n > 0){
 
			header('Location: cars.html'); 
		} else {
			
			
			echo "Incorrect username or password";
		}
	}
?>