<?php session_start();
/*
$connect = mysqli_connect("https://192.168.43.38", "web","web","isightdb");
function fill_brand($connect)
{
	$output = '';
	$sql = "SELECT * FROM user";
	
	$result = mysqli_query($connect,$sql);
	while($row = mysql_fetch_array($result))
	{
		$output .= '<option value="'.$row["user_id"].'">'.$row["surname"].'</option>';
	}
	return $output;
}
function fill_product($connect)
{
	$output = '';
	$sql = "SELECT * FROM user";
	$result = mysqli_query($connect,$sql);
	
	while($row = mysqli_fetch_array($result))
	{
		//$output .= '<div class="col-md-3">';
		//$output .= '<div style="border:1px solid #ccc; padding:20px; margin-bottom:20px;">'.$row["product_name"].'';
		//$output .= '<div style="padding:7px"> <input '.$row["first_name"].'';
		$output .= '<label>Surname</label><input type="text" name="surname" class="form-control" value="'.$row["first_name"].'" >';
		
		//$output .= '</div">';
		//$output .= '</div">';
	}
	return $output;
}

$user_id = 0;
$surname = "";
$first_name = "";
$email = "";
$phone = "";
$id_number = "";
$edit_state = false;


//$connect = mysqli_connect('localhost', 'root', '','isightdata');

	function getposts()
	{
		$posts = array();
		$posts[0] = $_POST["user_id"]; 
		$posts[1] = $_POST["surname"]; 
		$posts[2] = $_POST["first_name"]; 
		$posts[3] = $_POST["email"]; 
		$posts[3] = $_POST["phone"]; 
		$posts[3] = $_POST["id_number"]; 
		return $posts;
	}	
	
	//search
	if(isset($_POST['search']))
	{
		$data = getposts();
		$search_Query = "SELECT * FROM user where id = $data[0]";
		
		$search_Result = mysqli_query($connect, $search_Query);
		
		if($search_Result)
		{
			if(mysqli_num_rows($search_Result))
			{
				while($row = mysqli_fetch_array($search_Result))
				{
					$user_id = $row['user_id'];
					$surname = $row['surname'];
					$first_name = $row['first_name'];
					$email = $row['email'];
					$phone = $row['phone'];
					$id_number = $row['id_number'];
					
				}
			}
			else
			{
				echo 'no data found'; 
			}
			
		}
		else{
			echo 'Result Error';
		}
	
	}
	
	//isert
	
	if(isset($_POST['insert'])){
		
		$user_id = $_POST["user_id"];
		$surname = $_POST["surname"];
		$first_name = $_POST["first_name"];
		$email = $_POST["email"];
		$phone = $_POST["phone"];
		$id_number = $_POST["id_number"];		
			
		$insert_Query = "INSERT INTO user(surname,first_name,email,phone,id_number) VALUES('$surname','$first_name','$email','$phone','$id_number')";
		
		$search_Result = mysqli_query($connect, $insert_Query);
		$_SESSION['msg'] = "row inserted";
		}

	
	//update 
	
	if(isset($_POST['update']))
	{
		$user_id = mysql_real_escape_string($_POST["user_id"]); 
		$surname = mysql_real_escape_string($_POST["surname"]); 
		$first_name = mysql_real_escape_string($_POST["first_name"]); 
		$email = mysql_real_escape_string($_POST["email"]); 
		$phone = mysql_real_escape_string($_POST["phone"]); 
		$id_number = mysql_real_escape_string($_POST["id_number"]); 
		
		$update_Query = "UPDATE user SET user_id = '$user_id', surname='$surname', first_name= '$first_name', email = '$email' phone = '$phone' id_number = '$id_number' where user_id ='$user_id'";
		mysqli_query($connect, $update_Query);
	
	}
	
	//delete
	
	if(isset($_POST['delete']))
	{
		//$id = $_['delete'];
		$id = $_POST["user_id"]; 
			
		$delete_Query = "DELETE FROM user where user_id = '$user_id'";
		
		mysqli_query($connect, $delete_Query);
	}
*/

?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>User Info | ISight</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	
	<script src="js/jquery.js"></script>

    <!-- Custom CSS -->
    <link href="css/ISight.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">


</head>


<script> $(document).ready().getElementById("users").addEventListener("Click",function(e){
		if(e.target && e.target.matches("1")) {
			
			console.log(e.target);
		}
	
	
});

 </script>


<body>	
<!--?php if(isset($_SESSION['msg']));?>
	<div class='msg'>
		<?php 
			//echo $_SESSION['msg'];
			//nset($_SESSION['msg']);?>
	</div-->
<?php ?>	
	
    <div class="brand">ISight</div>
	  <div class="brand2">
				
				<h4>
				  <!--?php				
							include 'controllers/Controller.php';
							
							$run = new Controller();
							$id = $_SESSION['user_id'];
							$user = $run->getUserInfo($id);
							
							$name = $user[0]['surname'];
													
							echo $name;
						?-->
				</h4>
				
				
				</div>

    <!-- Navigation -->
    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- navbar-brand is hidden on larger screens, but visible when the menu is collapsed -->
				<a class="navbar-brand" href="index.html">ISight</a>
				
				
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
               <ul class="nav navbar-nav">
                    <li>
                        <a href="user.php">User Info</a>
                    </li>
					<li>
                        <a href="location.php">User Location</a>
                    </li>
                    <li>
                        <a href="items.php">User Items</a>
                    </li>
                    <li>
                        <a href="fav.php">User Fav Items</a>
                    </li>
					<li>
                        <a href="signOut.html">Sign Out</a>
                    </li>
					<li>
                      
				
                    </li>
                </ul>
				
            </div>
            <!-- /.navbar-collapse -->
			
        </div>
        <!-- /.container -->
    </nav>
	
	<div class="container">
        <div class="row">
            <div class="box">
                <div class="col-lg-12 text-left">
				
		  <h2>USERS</h2>                                                                                     
		  <div class="table-responsive">          
		  <table class="table">
			<thead>
			  <tr>
				<th>User ID</th>
				<th>Surname</th>
				<th>First Name</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Location ID</th>
				<th>ID Number</th>
			  </tr>
			</thead>
			<tbody>
			<!--?php 				

				$user = $run->getAllUser();
							
				$name = $user[0]['surname'];
				$first_name = $user[0]['first_name'];
				$id_number = $user[0]['id_number'];
				$email = $user[0]['email'];
				$phone = $user[0]['phone'];
				$user_id = $user[0]['user_id'];
							
					foreach($user as $row)
					  {
					  echo "<tr>";
						echo "<td>" . $row['user_id'] . "</td>";
						echo "<td>" . $row['surname'] . "</td>";
						echo "<td>" . $row['first_name'] . "</td>";
						echo "<td>" . $row['email'] . "</td>";
						echo "<td>" . $row['phone'] . "</td>";
						echo "<td>" . $row['location_id'] . "</td>";
						echo "<td>" . $row['id_number'] . "</td>";
					  echo "</tr>";
					  }
					echo "</table>";
			?--><!--? end;?-->
			</tbody>
		  </table>
		  </div>
		</div>	
				</div>	
			</div>
		</div>
	</div>
	
	<div class="container">
        <div class="row">
            <div class="box">
                <div class="col-lg-12 text-left">
					<h3>User Information</h3>
					
								<div class="container">
									  <p>Please select the user from the select below</p>
									  
											<select name= "brands" id = "brands">
											  
											  <option value = ""> select user id</option>
												<!--?php
												
												$user = $run->getAllUser();
												foreach($user as $usr_id):?>
													
														 <option value = "<!?php echo $usr_id['user_id'];?>" > <!?php echo $usr_id['user_id'];?> </option>																					  
														
														<!--?php echo fill_brand($connect);?-->	
														
												<!--?php endforeach?-->
											</select>
										
										
										<!--input type="submit" value="submit id" id='clickme'>
										<script> 
											$('#clickme').click(function() 
												{       
													$('#result').html('cfcc')  
												})  
										</script>
										<p id='result'> im daniel </p-->
								</div>
					
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="box">
                <div class="col-lg-12">
                   
                    <form role="form" action = "">
                        <div class="row">
							
					<br /><br />
					<p> 
						<div class = "row" id="show_product">
							<!--?php echo fill_product($connect);?-->
						</div>
					</p>
					<script>
						$(document).ready(function(){
							$('#brands').change(function(){
								var user_id = $(this).val();
								
								$.ajax({
									url:"load_data.php",
									methord:"POST",
									data:{user_id:user_id},
									success:function(data){
										$('#show_product').html(data);
									}
								});
							});
						});
					</script>
					
                            <div class="form-group col-lg-2">
                                <label>Surname</label>							
                                <input type="text" name="surname" class="form-control" value="<!--?php echo $user_id[2]['user_id'];?> "-- >
                            </div>
                            <div class="form-group col-lg-2">
                                <label>First Name</label>
                                <input type="first_name" name="first_name" class="form-control" value="<!--?php echo $user_id[0]['first_name'];?-->">
                            </div>
							<div class="form-group col-lg-2">
                                <label>ID Number</label>
                                <!--?php echo $user_id[0]['id_number'];?-->
                            </div>
                            <div class="form-group col-lg-2">
                                <label>Email Address</label>
                                <input type="email" name="email" class="form-control" value="<!--?php echo $user_id[0]['email'];?>"-->
                            </div>
							<div class="form-group col-lg-2">
                                <label>Contact Numbers</label>
                                <input type="phone" name="phone" class="form-control" value="<!--?php echo $user_id[0]['phone'];?>"-->
                            </div>
							<div class="form-group col-lg-2">
                                <label>Location</label>
									<div class="dropdown">
										<button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" name="search">location
											<span class="caret"></span></button>
												<ul class="dropdown-menu" >
													<!--?php
														$location = $run->getloction();
							
														$city = $location[0]['city'];
														
														echo $city;
													?-->
												</ul>
									</div>
							 </div>
							 
							  <div class="form-group col-lg-2">
                                <div class="race">
									<label>Add Race</label></br>
										<input type="radio" name="Race" onclick="myFunction()" checked>Black
										</br>
										<input type="radio" name="Race" onclick="myFunction()" checked>White
										</br>
										<input type="radio" name="Race" onclick="myFunction()" checked>Coloured
										</br>
										<input type="radio" name="Race" onclick="myFunction()" checked>Indian
								</div>
                            </div>
							
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

	<form role="form" action="">
    <div class="container">

        <div class="row">
            <div class="box">
                <div class="col-lg-12 text-center">
				
					<div class="form-group col-lg-12">
                    <input type="hidden" name="save" value="contact">
                    <button type="submit" class="btn btn-default" name = "insert">Add User</button>
                    </div>
					
					<div class="form-group col-lg-12">
                    <input type="hidden" name="save" value="contact">
                    <button type="submit" class="btn btn-default" name = "delete">Delete User</button>
                    </div>
					
					<div class="form-group col-lg-12">
                    <input type="hidden" name="save" value="contact">
                    <button type="submit" class="btn btn-default" name = "update">Update User</button>
                    </div>
				
					<p> if you want to edit your profile <a href = "profile.php">Click here</a></p>
					<!--br /><br />
					<p> 
						<div class = "row" id="show_product">
							<!?php echo fill_product($connect);?>
						</div>
					</p>
					<script>
						$(document).ready(function(){
							$('#brands').change(function(){
								var user_id = $(this).val();
								
								$.ajax({
									url:"load_data.php",
									methord:"POST",
									data:{user_id:user_id},
									success:function(data){
										$('#show_product').html(data);
									}
								});
							});
						});
					</script-->
	
			
				</div>
			</div>
		</div>	
	</div>
	</form>
    <!-- /.container -->
    <!--div class="container">

        <div class="row">
            <div class="box">
                <div class="col-lg-12 text-center">
				
						<select name="garden" multiple="multiple">
						  <option>Flowers</option>
						  <option>Shrubs</option>
						  <option>Trees</option>
						  <option>Bushes</option>
						  <option>Grass</option>
						  <option>Dirt</option>
						</select>
						<h5></h5>
						<br /><br /><h4> 
				<div id="show_product">
					</?php echo fill_product($connect);?>
				</div></h4>
	
						 
						<script>
						$( "select" )
						  .change(function() {
							var str = "";
							$( "select option:selected" ).each(function() {
							  str += $( this ).text() + " ";
							});
							$( "h5" ).text( str );
						  })
						  .trigger( "change" );
						 
						</script>
			
				</div>
			</div>
		</div>	
	</div-->
    <!-- /.container -->


    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>Copyright &copy ISight<br />
						Design &amp development by TeamVisionTUT<br />
					</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
	
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

